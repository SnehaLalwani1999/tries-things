window.InitUserScripts = function()
{
var player = GetPlayer();
var object = player.object;
var addToTimeline = player.addToTimeline;
var setVar = player.SetVar;
var getVar = player.GetVar;
window.Script5 = function()
{
  //Getting the player
const player = GetPlayer();

//Where to start
var sec = 180;

//Set up the timer
function startTimer(){
  sec -= 1;
  player.SetVar("countdown",sec);
  if (sec < 0) {
    clearInterval(timerId);
    player.SetVar("countdown","Times Up")
  }
}

//Start the timer
timerId=setInterval(startTimer,1000);
}

};
