function ExecuteScript(strId)
{
  switch (strId)
  {
      case "6FSSu9aX32N":
        Script1();
        break;
      case "5tVYychgJoI":
        Script2();
        break;
      case "6VaU9vw7ME6":
        Script3();
        break;
      case "5VOUkVtW4oG":
        Script4();
        break;
      case "6L2MFXsjWnv":
        Script5();
        break;
  }
}

window.InitExecuteScripts = function()
{
var player = GetPlayer();
var object = player.object;
var addToTimeline = player.addToTimeline;
var setVar = player.SetVar;
var getVar = player.GetVar;
window.Script1 = function()
{
  const target = object('62cvu8NfJje');
const duration = 750;
const easing = 'ease-out';
const id = '64DPbBUzW6b';
const pulseAmount = 0.07;
player.addForTriggers(
id,
target.animate([
{ scale: '1' }, { scale: `${1 + pulseAmount}` },
{ scale: '1' }, { scale: `${1 + pulseAmount}` },
{ scale: '1' }
],
  { fill: 'forwards', duration, easing }
)
);
}

window.Script2 = function()
{
  const target = object('5zQF3CHOA1g');
const duration = 750;
const easing = 'ease-out';
const id = '5rS4HsaLVci';
const shakeAmount = 2;
player.addForTriggers(
id,
target.animate([
{ translate: '0 0' },
{ translate: `-${shakeAmount}px 0` },
{ translate: '0 0' },
{ translate: `${shakeAmount}px 0` },
{ translate: '0 0' },
{ translate: `-${shakeAmount}px 0` },
{ translate: '0 0' }
],
  { fill: 'forwards', duration, easing }
)
);
}

window.Script3 = function()
{
  const target = object('5vlxF209m7y');
const duration = 750;
const easing = 'ease-out';
const id = '5nyU5iaBqPF';
const pulseAmount = 0.07;
player.addForTriggers(
id,
target.animate([
{ scale: '1' }, { scale: `${1 + pulseAmount}` },
{ scale: '1' }, { scale: `${1 + pulseAmount}` },
{ scale: '1' }
],
  { fill: 'forwards', duration, easing }
)
);
}

window.Script4 = function()
{
  const target = object('5qjzOiyUPLN');
const duration = 750;
const easing = 'ease-out';
const id = '5Xo2n4XJnSS';
const pulseAmount = 0.07;
player.addForTriggers(
id,
target.animate([
{ scale: '1' }, { scale: `${1 + pulseAmount}` },
{ scale: '1' }, { scale: `${1 + pulseAmount}` },
{ scale: '1' }
],
  { fill: 'forwards', duration, easing }
)
);
}

};
